---
# Display name
name: Hafiz Mughees Ahmad

# Username (this should match the folder name)
authors:
- admin

# Is this the primary user of the site?
superuser: true

# Role/position
role: Research Engineer @ iVisionLab

# Organizations/Affiliations
organizations:
- name: Institute of Space Technology, Pakistan
  url: "www.ist.edu.pk"

# Short bio (displayed in user profile at end of posts)
bio: My research interests Computer Vision and Deep Learning

interests:
- Artificial Intelligence
- Deep Learning
- Computer Vision
- Medical Image Processing

education:
  courses:
  - course: MS in Computer Vision and Deep Learning
    institution: Institute of Space Technology, Pakistan
    year: 2018
  - course: BS in Electrical Engineering
    institution: Institute of Space Technology, Pakistan
    year: 2015

# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/widgets/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: '#contact'  # For a direct email link, use "mailto:ahmadmughees@outlook.com".
- icon: twitter
  icon_pack: fab
  link: https://twitter.com/itsmughees
- icon: google-scholar
  icon_pack: ai
  link: https://scholar.google.com/citations?user=uZSLvBIAAAAJ&hl=en
- icon: github
  icon_pack: fab
  link: https://github.com/mugheesahmad
# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.  
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""
  
# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.  
user_groups:
- Researchers
- Visitors
---

Mughees Ahmad is a Lecturer and Research Engineer at iVision Lab. His research interest include Computer Vision, Deep Learning and medical image processing. He has completed multiple projects in the different domains of Computer Vision.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed neque elit, tristique placerat feugiat ac, facilisis vitae arcu. Proin eget egestas augue. Praesent ut sem nec arcu pellentesque aliquet. Duis dapibus diam vel metus tempus vulputate. 
